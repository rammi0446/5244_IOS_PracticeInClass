//
//  GameScene.swift
//  ios2d-Berzerk
//
//  Created by Parrot on 2019-06-12.
//  Copyright © 2019 Parrot. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene, SKPhysicsContactDelegate {
    
    //sprites
    //player
    var player:SKNode!
    var enemiesArray:[SKNode] = []
    var evil:SKNode!
    var loseVar:Bool = false
    
    
    override func didMove(to view: SKView) {
        // Required for SKPhysicsContactDelegate
        self.physicsWorld.contactDelegate = self
        self.player = self.childNode(withName: "player")
        
        //add enemy to to array
        let e1 = self.childNode(withName: "enemy1")
        let e2 = self.childNode(withName: "enemy2")
        let e3 = self.childNode(withName: "enemy3")
        let e4 = self.childNode(withName: "enemy4")
        self.enemiesArray.append(e1!)
        self.enemiesArray.append(e2!)
        self.enemiesArray.append(e3!)
        self.enemiesArray.append(e4!)
        //get evil
        self.evil = self.childNode(withName: "evil")
    }
    
    // MARK: Function to notify us when two sprites touch
    func didBegin(_ contact: SKPhysicsContact) {
        
        
        let nodeA = contact.bodyA.node
        let nodeB = contact.bodyB.node
        
        if(nodeA!.name == "player" && nodeB!.name == "exit")
        {
        
            print("player touch the exit")
        
        //Game win, display messege and flip screen , when player touch the exit
        let messegeLabel = SKLabelNode(text: "you win")
        messegeLabel.fontColor = UIColor.yellow
        messegeLabel.fontSize = 60
        messegeLabel.position.x = self.size.width/2
        messegeLabel.position.y = self.size.height/2
        addChild(messegeLabel)
            
            //go to next two
            let level2Scene = SKScene(fileNamed:"level02")
            level2Scene!.scaleMode = .aspectFill
            let flipTransition = SKTransition.flipVertical(withDuration: 2)
            self.scene?.view?.presentScene(
                level2Scene!,
                transition: flipTransition)
      
        }
        if(nodeA!.name == "exit" && nodeB!.name == "player")
        {
            
            print("player touch the exit")
            
            //Game win
            let messegeLabel = SKLabelNode(text: "you win")
            messegeLabel.fontColor = UIColor.yellow
            messegeLabel.fontSize = 60
            messegeLabel.position.x = self.size.width/2
            messegeLabel.position.y = self.size.height/2
            addChild(messegeLabel)
            //go to next level
            let level2Scene = SKScene(fileNamed:"level2")
            level2Scene!.scaleMode = .aspectFill
            let flipTransition = SKTransition.flipVertical(withDuration: 2)
            self.scene?.view?.presentScene(
                level2Scene!,
                transition: flipTransition)
            
        }
        
        //game lose,display messege and flip screen, when enemies touch the player
        
        if(nodeA!.name == "player" && nodeB!.name == "enemy1")
        {
            print("Lose")
            self.lose()
            
        }
        if(nodeA!.name == "enemy1" && nodeB!.name == "player")
        {
            print("Lose")
             self.lose()
        }
        
    }//end of the begin function
    
    var timeofLastUpdate:TimeInterval = -1
    var MovingEvil:Bool = true
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        
        //move enemy
        if(loseVar == false)
        {
        self.moveEnemy()
        }
        
        
        if(timeofLastUpdate == -1)
        {
            timeofLastUpdate = currentTime
        }
        
        let timePassed = currentTime - timeofLastUpdate
        if(timePassed >= 5)
        {
            print("5 seconds")
            timeofLastUpdate = currentTime
            
            if(MovingEvil == false)
            {
                MovingEvil = true
            }
            evil.position.x  = evil.position.x + 10
        }
        //move evil
        if(MovingEvil == true)
        {
             evil.position.x  = evil.position.x + 10
        }
        
    }
    
    //up down left right button touch
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first
        if(touch == nil)
        {
            return
        }
        
        let mouseLocation = touch!.location(in: self)
        let spriteTouch = self.atPoint(mouseLocation)
        
        //if person pressed the butotn
        if(spriteTouch.name == "up")
        {
            print("up button")
            self.player.position.y = self.player.position.y + 20
            
        }
        if(spriteTouch.name == "down")
        {
            print("down button")
            self.player.position.y = self.player.position.y - 20
            
        }
        if(spriteTouch.name == "left")
        {
            print("left button")
            self.player.position.x = self.player.position.x - 20
            
        }
        if(spriteTouch.name == "right")
        {
            print("rightbutton")
            self.player.position.x = self.player.position.x + 20
            
        }
    }
    
    
    
    //Custom functions to move enemies and lose
    func moveEnemy()
    {
       
        //loop through al your enemy
        for (index,enemy) in self.enemiesArray.enumerated(){
            let a = self.player.position.x - enemy.position.x
            let b =  self.player.position.y - enemy.position.y
            let d = sqrt(a*a + b*b)
            let xn = a / d
            let yn = b / d
            
            let enemy_Speed:CGFloat = 2
            
            //update position
            enemy.position.x = enemy.position.x + xn * enemy_Speed
            enemy.position.y = enemy.position.y + yn * enemy_Speed
            //for each enemy node do the vector math calcultion
        }
        
        
        //math
        
    }
    
    func lose()
    {
        loseVar = true
        let messegeLabel = SKLabelNode(text: "you lose")
        messegeLabel.fontColor = UIColor.yellow
        messegeLabel.fontSize = 60
        messegeLabel.position.x = self.size.width/2
        messegeLabel.position.y = self.size.height/2
        addChild(messegeLabel)
    }
    
}

